# Phase 1 — Server Foundation

## What we are building in this phase
The Express server skeleton. No features yet — just the infrastructure
that everything else will be built on top of. Think of it as wiring
the electricity and plumbing in a building before any rooms are furnished.

## Rules before you start
- Read server/CLAUDE.md first
- TypeScript strict mode on all files
- No `any` types
- Error responses always use shape: { error: { code: string, message: string } }
- Use named exports except where noted
- Never log secrets, passwords, or tokens

## Files to create

### server/src/lib/prisma.ts
Singleton Prisma client.
- Import PrismaClient from @prisma/client
- Use the standard singleton pattern that prevents multiple instances
  during hot reload in development (store on globalThis)
- Export a single named `prisma` instance
- Log a message when connected

### server/src/lib/redis.ts
Singleton IORedis client.
- Read REDIS_URL from process.env
- Export a single named `redis` instance
- On connection event: log "Redis connected"
- On error event: log the error with message "Redis connection error"

### server/src/lib/logger.ts
Winston logger.
- In development (NODE_ENV !== production): colorized console output
  with format: timestamp + level + message
- In production: JSON format
- Export as default `logger`

### server/src/middleware/errorHandler.ts
Global Express error handler. This is the last middleware in the chain —
it catches anything that goes wrong anywhere in the app.
- Function signature: (err, req, res, next) — all four params required
  for Express to recognise it as an error handler
- Map these error types:
  - Prisma error P2025 → 404, code "NOT_FOUND"
  - Prisma error P2002 → 409, code "CONFLICT"
  - ZodError → 400, code "VALIDATION_ERROR", include the first issue message
  - Everything else → 500, code "INTERNAL_ERROR"
- In development: include err.message in the response
- In production: use a generic message for 500 errors, never expose internals
- Always use this response shape: { error: { code: string, message: string } }

### server/src/middleware/auth.ts
JWT authentication middleware.
- Read the Bearer token from the Authorization header
- Verify using JWT_SECRET from process.env
- The JWT payload contains: { id, email, role, workspaceId }
- On success: attach the decoded payload to req.user and call next()
- On any failure (missing token, invalid, expired):
  return 401 { error: { code: "UNAUTHORIZED", message: "Invalid or expired token" } }
- Export as named export `authenticate`
- Also export TypeScript declaration that extends Express Request
  to include req.user with type { id: string, email: string, role: string, workspaceId: string }

### server/src/index.ts
Main entry point. Wire everything together in this exact order:

1. Load dotenv — point it to .env in the parent directory (../.env)
2. Import logger, prisma, redis
3. Create Express app
4. Create HTTP server from the Express app
5. Attach Socket.IO to the HTTP server with cors origin: process.env.CLIENT_URL or 'http://localhost:5173'

Middleware stack (order matters):
- cors: allow origin http://localhost:5173, credentials true
- morgan: 'dev' format in development
- express.json() with 10mb limit
- cookie-parser
- express-rate-limit: 100 requests per 15 minutes per IP,
  message { error: { code: "RATE_LIMITED", message: "Too many requests" } }

Routes:
- GET /health → return 200 { status: "ok", timestamp: new Date().toISOString(), environment: NODE_ENV }
- Mount /api/v1 router (create an empty router in src/routes/index.ts and mount it here)

Socket.IO events:
- connection: log "Socket client connected: {socket.id}"
- disconnect: log "Socket client disconnected: {socket.id}"

Error handling:
- Mount errorHandler as the very last middleware (after all routes)
- Handle unhandledRejection and uncaughtException — log the error and exit process

Start:
- Listen on PORT from process.env (default 3001)
- On listen: log "Regi server running on port {PORT}"

### server/src/routes/index.ts
Empty API router for now.
- Create an Express Router
- Export as default
- Add a comment: "Routes will be added here in later phases"

### server/tsconfig.json
Update to add path alias:
- Add baseUrl: "./src"
- Add paths: { "@/*": ["./*"] }
- Ensure strict: true, esModuleInterop: true, outDir: "./dist"
- Target: ES2020, module: commonjs

## After creating all files

1. From the server/ directory run: npm run dev
2. Show me the full startup log output
3. In a separate terminal run: curl http://localhost:3001/health
4. Show me the response
5. If there are any TypeScript errors, fix them before showing me the output
6. Do NOT move to any other phase — stop here and wait for confirmation
