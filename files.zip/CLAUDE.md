# Regi — AI QA Assistant

## What this app does
Regi takes a Jira ticket or pasted requirement and uses an LLM to generate
structured test cases. QA engineers review, edit, and export to Zephyr Scale or CSV.

## Tech stack
- Frontend: React 18, Vite, Zustand, shadcn/ui, Tailwind, Socket.IO client
- Backend: Node 20, Express, Prisma, MySQL 8, Redis, BullMQ
- Auth: JWT (15min access) + HTTP-only refresh token (7 days)
- LLM: Provider-agnostic layer — default OpenAI GPT-4o

## Monorepo structure
- client/   React SPA (port 5173)
- server/   Node.js API + workers (port 3001)

## Branch rules
- feature/* for new features
- fix/* for bug fixes
- Never commit directly to main or develop

## Environment
- Copy .env.example to .env and fill values
- docker compose up -d starts MySQL + Redis locally
- server runs on :3001, client on :5173

## Build task files
All phase instructions are in .claude/tasks/
Read the current phase file before starting any work.

## Current phase
phase-1-server-foundation.md

## Phase status
- phase-1-server-foundation.md → 🔵 in progress
- phase-2-authentication.md → 🔲 pending
- phase-3-projects.md → 🔲 pending
- phase-4-ticket-ingestion.md → 🔲 pending
- phase-5-llm-generation.md → 🔲 pending
- phase-6-review-editing.md → 🔲 pending
- phase-7-export.md → 🔲 pending

## Architecture decisions
See .claude/decisions/architecture.md for why key decisions were made.

## Never do
- Never run prisma migrate dev automatically — show SQL first, wait for human approval
- Never store secrets or API keys in code or comments
- Never put business logic inside route files
- Never use var — only const and let
- Never call OpenAI or Anthropic SDK directly from a controller or route
- Never use any TypeScript type — fix the type properly
- Never store refresh tokens in localStorage or response body
